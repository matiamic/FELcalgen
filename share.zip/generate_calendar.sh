#! /bin/bash
if [ ! -d calgen_env ]
then
    ./install_env.sh
fi
source calgen_env/bin/activate
clear
python3 calgen.py
deactivate

